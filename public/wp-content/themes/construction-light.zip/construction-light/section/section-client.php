<?php
/**
 * Template part for displaying front page section
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Construction Light
 */

/**
 * Hook -  costruction_light_action_clients
 *
 * @hooked costruction_light_clients - 80
 */

do_action('costruction_light_action_clients');