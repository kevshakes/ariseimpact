<?php
/**
 * Template part for displaying front page section
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Construction Light
 */

/**
 * Hook -  construction_light_action_blog
 *
 * @hooked construction_light_blog - 65
 */

do_action('construction_light_action_blog');